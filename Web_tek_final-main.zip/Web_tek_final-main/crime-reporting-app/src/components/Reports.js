import React from 'react';

const Reports = () => {
  return (
    <div>
      <h2>Reports Page</h2>
      {/* Reports details go here */}
    </div>
  );
};

export default Reports;
